#config file containing credentials for rds mysql instance
db_username = "shareHomeLambda"
db_password = "k9gqVq1qvYtfnuoZjEOgX1I3v"
db_name = "shareHome" 
host_name = "alexadb.cronjdkqzkod.us-east-1.rds.amazonaws.com"
