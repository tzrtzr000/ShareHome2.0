def init():
    global cnx, cursor
    cnx = None
    cursor = None

