aws_access_key_id = "AKIAIYC7YIOZJWHZRISA"
aws_secret_access_key = "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"
region = 'us-east-1'
UserPoolId = "us-east-1_tJCPtikyk"
pinpoint_application_id = '421d51c0021f4a91877303e9fed52cc4'
pinpoint_allUsers_SegmentId = 'a1a378598b1346c0bb199874181ff542'
pinpoint_allUsers_SegmentVersion = 1
